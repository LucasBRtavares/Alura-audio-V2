function tocaSomPom(){
    document.querySelector('#som_tecla_pom').play();
}
function tocaSomClap(){
    document.querySelector('#som_tecla_clap').play();
}
function tocaSomTim(){
    document.querySelector('#som_tecla_tim').play();
}
function tocaSomPuff(){
    document.querySelector('#som_tecla_puff').play();
}
function tocaSomSplash(){
    document.querySelector('#som_tecla_splah').play();
}
function tocaSomToim(){
    document.querySelector('#som_tecla_toim').play();
}
function tocaSomPsh(){
    document.querySelector('#som_tecla_psh').play();
}
function tocaSomTic(){
    document.querySelector('#som_tecla_tic').play();
}
function tocaSomTom(){
    document.querySelector('#som_tecla_tom').play();
}
